export default async function handler(req, res) {
  const raw = String(req.query.symbol || '').trim().toUpperCase();
  if (!raw) return res.status(400).json({error:'請輸入股票代號'});
  const symbol = /^\d{4,6}$/.test(raw) ? `${raw}.TW` : raw;
  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=6mo&interval=1d&includePrePost=false`;
    const r = await fetch(url, {headers:{'User-Agent':'Mozilla/5.0','Accept':'application/json'}});
    if (!r.ok) throw new Error(`行情服務錯誤 ${r.status}`);
    const data = await r.json();
    const x = data?.chart?.result?.[0];
    if (!x) throw new Error('找不到此股票');
    const q = x.indicators?.quote?.[0] || {};
    const rows = (x.timestamp||[]).map((t,i)=>({t,open:q.open?.[i],high:q.high?.[i],low:q.low?.[i],close:q.close?.[i],volume:q.volume?.[i]})).filter(v=>Number.isFinite(v.close)&&Number.isFinite(v.high)&&Number.isFinite(v.low));
    if(rows.length<30) throw new Error('歷史資料不足');
    res.setHeader('Cache-Control','s-maxage=60, stale-while-revalidate=300');
    return res.status(200).json({symbol, name:x.meta?.longName||x.meta?.shortName||symbol, currency:x.meta?.currency||'', rows});
  } catch(e){ return res.status(500).json({error:e.message||'抓取行情失敗'}); }
}
